drop package COMPANY;
drop table EMPLOYEES;
drop type EMPLOYEE force;
drop type ADDRESS force;
drop table EMPLOYEE_ACCOUNTS;
drop table EMPLOYEE_BIODATA;
drop table EMPLOYEE_IMAGE;
drop table EMPLOYEE_HIREDATE;
drop table EMPLOYEE_ESPP;
