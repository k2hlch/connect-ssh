package oracle.j2ee.ws_example;

public interface StatelessExample {
  String helloWorld(String param);
}
