package oracle.j2ee.ws_example;

public interface StatefulExample {
int count();
String helloWorld(String param);
}
