package oracle.j2ee.ws_example;

public interface BeanExample {

    void setTestBean(TestBean b);

    TestBean getTestBean();
}

