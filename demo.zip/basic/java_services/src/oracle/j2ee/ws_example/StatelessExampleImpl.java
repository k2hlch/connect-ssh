package oracle.j2ee.ws_example;

public class StatelessExampleImpl {
  public StatelessExampleImpl() {
  }
  public String helloWorld(String param) {
    return "Hello World, " + param;
  }
}
